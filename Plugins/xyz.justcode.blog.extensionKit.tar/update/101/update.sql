UPDATE blog1_entry SET isFeatured = 1 WHERE isSticky = 1;
ALTER TABLE blog1_entry DROP COLUMN isSticky;